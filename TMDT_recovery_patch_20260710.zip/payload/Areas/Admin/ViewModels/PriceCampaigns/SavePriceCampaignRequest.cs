using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Areas.Admin.ViewModels.PriceCampaigns;

public sealed class SavePriceCampaignRequest
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tên chiến dịch.")]
    [StringLength(255, ErrorMessage = "Tên chiến dịch không được vượt quá 255 ký tự.")]
    public string Name { get; set; } = string.Empty;

    public string? Description { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime EndDate { get; set; }

    [MinLength(1, ErrorMessage = "Vui lòng chọn ít nhất một biến thể.")]
    public List<SavePriceCampaignItemRequest> Items { get; set; } = [];

    [StringLength(200)]
    public string? RowVersion { get; set; }
}

public sealed class SavePriceCampaignItemRequest
{
    [Range(1, int.MaxValue, ErrorMessage = "ID biến thể không hợp lệ.")]
    public int VariantId { get; set; }

    [Range(typeof(decimal), "0.01", "9999999999999999", ErrorMessage = "Giá chiến dịch phải lớn hơn 0.")]
    public decimal NewPrice { get; set; }
}
