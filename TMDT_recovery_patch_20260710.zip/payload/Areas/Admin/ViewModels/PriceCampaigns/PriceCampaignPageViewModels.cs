using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebApplication2.Areas.Admin.ViewModels.PriceCampaigns;

public sealed class PriceCampaignIndexPageViewModel
{
    public DateTime UtcNow { get; init; }

    public IReadOnlyList<PriceCampaignListItemViewModel> Items { get; init; } = [];
}

public sealed class PriceCampaignListItemViewModel
{
    public int Id { get; init; }

    public string Name { get; init; } = string.Empty;

    public string? Description { get; init; }

    public DateTime StartDateUtc { get; init; }

    public DateTime EndDateUtc { get; init; }

    public bool IsActive { get; init; }

    public int VariantCount { get; init; }

    public string RowVersion { get; init; } = string.Empty;

    public string Status { get; init; } = string.Empty;
}

public sealed class PriceCampaignEditorPageViewModel
{
    public int CampaignId { get; init; }

    public IReadOnlyList<SelectListItem> CategoryOptions { get; init; } = [];

    public IReadOnlyList<SelectListItem> BrandOptions { get; init; } = [];
}

public sealed class ApplyPriceCampaignRequest
{
    public int Id { get; set; }

    public string RowVersion { get; set; } = string.Empty;
}
