using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplication2.Migrations;

public partial class CompletePriceCampaignConsistency : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        // The previous migration created CurrentPrice with a zero default.
        // Backfill before enforcing the positive-price invariant.
        migrationBuilder.Sql(
            "UPDATE [ProductVariants] SET [CurrentPrice] = [Price] WHERE [CurrentPrice] <= 0;");

        // Keep only one main image per product before adding the filtered unique index.
        migrationBuilder.Sql(
            """
            ;WITH RankedMainImages AS
            (
                SELECT [Id],
                       ROW_NUMBER() OVER (PARTITION BY [ProductId] ORDER BY [Id]) AS [RowNumber]
                FROM [ProductImage]
                WHERE [IsMain] = 1
            )
            UPDATE [ProductImage]
            SET [IsMain] = 0
            WHERE [Id] IN
            (
                SELECT [Id]
                FROM RankedMainImages
                WHERE [RowNumber] > 1
            );
            """);

        migrationBuilder.Sql(
            """
            IF EXISTS (SELECT 1 FROM [PriceCampaignItems] WHERE [NewPrice] <= 0)
                THROW 51000, 'PriceCampaignItems contains non-positive NewPrice values. Correct the data before applying this migration.', 1;
            """);

        migrationBuilder.AddColumn<byte[]>(
            name: "RowVersion",
            table: "PriceCampaigns",
            type: "rowversion",
            rowVersion: true,
            nullable: false);

        migrationBuilder.AddColumn<byte[]>(
            name: "RowVersion",
            table: "ProductVariants",
            type: "rowversion",
            rowVersion: true,
            nullable: false);

        migrationBuilder.AddCheckConstraint(
            name: "CK_ProductVariant_CurrentPrice",
            table: "ProductVariants",
            sql: "[CurrentPrice] > 0");

        migrationBuilder.AddCheckConstraint(
            name: "CK_PriceCampaignItem_NewPrice",
            table: "PriceCampaignItems",
            sql: "[NewPrice] > 0");

        migrationBuilder.DropIndex(
            name: "IX_ProductImage_ProductId",
            table: "ProductImage");

        migrationBuilder.DropIndex(
            name: "IX_ProductVariants_ProductId",
            table: "ProductVariants");

        migrationBuilder.DropIndex(
            name: "IX_PriceHistories_ProductVariantId",
            table: "PriceHistories");

        migrationBuilder.CreateIndex(
            name: "IX_ProductImage_ProductId_IsMain",
            table: "ProductImage",
            columns: new[] { "ProductId", "IsMain" },
            unique: true,
            filter: "[IsMain] = 1");

        migrationBuilder.CreateIndex(
            name: "IX_ProductVariants_ProductId_IsActive",
            table: "ProductVariants",
            columns: new[] { "ProductId", "IsActive" });

        migrationBuilder.CreateIndex(
            name: "IX_PriceHistories_ProductVariantId_CreatedAt",
            table: "PriceHistories",
            columns: new[] { "ProductVariantId", "CreatedAt" });
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(
            name: "IX_ProductImage_ProductId_IsMain",
            table: "ProductImage");

        migrationBuilder.DropIndex(
            name: "IX_ProductVariants_ProductId_IsActive",
            table: "ProductVariants");

        migrationBuilder.DropIndex(
            name: "IX_PriceHistories_ProductVariantId_CreatedAt",
            table: "PriceHistories");

        migrationBuilder.DropCheckConstraint(
            name: "CK_ProductVariant_CurrentPrice",
            table: "ProductVariants");

        migrationBuilder.DropCheckConstraint(
            name: "CK_PriceCampaignItem_NewPrice",
            table: "PriceCampaignItems");

        migrationBuilder.DropColumn(
            name: "RowVersion",
            table: "PriceCampaigns");

        migrationBuilder.DropColumn(
            name: "RowVersion",
            table: "ProductVariants");

        migrationBuilder.CreateIndex(
            name: "IX_ProductImage_ProductId",
            table: "ProductImage",
            column: "ProductId");

        migrationBuilder.CreateIndex(
            name: "IX_ProductVariants_ProductId",
            table: "ProductVariants",
            column: "ProductId");

        migrationBuilder.CreateIndex(
            name: "IX_PriceHistories_ProductVariantId",
            table: "PriceHistories",
            column: "ProductVariantId");
    }
}
