(() => {
    "use strict";

    const http = window.FastBuyHttp;
    if (!http) return;

    const currency = new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND", maximumFractionDigits: 0 });

    function setFeedback(container, message, type = "") {
        if (!container) return;
        container.textContent = message ?? "";
        container.classList.remove("is-error", "is-success");
        if (type) container.classList.add(`is-${type}`);
    }

    function toLocalInput(isoValue) {
        const date = new Date(isoValue);
        if (Number.isNaN(date.getTime())) return "";
        const offset = date.getTimezoneOffset() * 60000;
        return new Date(date.getTime() - offset).toISOString().slice(0, 16);
    }

    function initializeIndex(root) {
        const feedback = root.querySelector("[data-page-feedback]");

        root.querySelectorAll("[data-local-datetime]").forEach((element) => {
            const date = new Date(element.dateTime);
            if (!Number.isNaN(date.getTime())) {
                element.textContent = new Intl.DateTimeFormat("vi-VN", {
                    dateStyle: "short",
                    timeStyle: "short"
                }).format(date);
            }
        });

        root.addEventListener("click", async (event) => {
            const button = event.target.closest("[data-apply-campaign]");
            if (!button) return;

            const row = button.closest("[data-campaign-row]");
            if (!row) return;

            if (!window.confirm("Kích hoạt chiến dịch này ngay bây giờ?")) return;

            button.disabled = true;
            setFeedback(feedback, "Đang kích hoạt chiến dịch...");
            try {
                const result = await http.postJson("/Admin/PriceCampaigns/ApplyNow", {
                    id: Number(row.dataset.campaignId),
                    rowVersion: row.dataset.rowVersion
                });

                if (!result.success) throw new Error(result.message ?? "Không thể kích hoạt chiến dịch.");
                setFeedback(feedback, result.message, "success");
                window.setTimeout(() => window.location.reload(), 450);
            } catch (error) {
                setFeedback(feedback, error.message, "error");
                button.disabled = false;
            }
        });
    }

    function initializeEditor(root) {
        const campaignId = Number(root.dataset.campaignId ?? 0);
        const feedback = root.querySelector("[data-page-feedback]");
        const sourceList = root.querySelector("[data-source-list]");
        const selectedList = root.querySelector("[data-selected-list]");
        const selectedCount = root.querySelector("[data-selected-count]");
        const saveSummary = root.querySelector("[data-save-summary]");
        const rowVersionInput = root.querySelector("[data-campaign-row-version]");
        const selected = new Map();
        let sourceProducts = [];
        let searchAbortController = null;

        function createText(tag, className, text) {
            const element = document.createElement(tag);
            if (className) element.className = className;
            element.textContent = text;
            return element;
        }

        function renderSource() {
            sourceList.replaceChildren();
            const availableProducts = sourceProducts
                .map((product) => ({
                    ...product,
                    variants: product.variants.filter((variant) => !selected.has(variant.id))
                }))
                .filter((product) => product.variants.length > 0);

            if (!availableProducts.length) {
                sourceList.append(createText("div", "empty-state compact", "Không có biến thể phù hợp."));
                return;
            }

            availableProducts.forEach((product) => {
                product.variants.forEach((variant) => {
                    const row = document.createElement("article");
                    row.className = "variant-option";

                    const checkbox = document.createElement("input");
                    checkbox.type = "checkbox";
                    checkbox.className = "form-check-input";
                    checkbox.setAttribute("aria-label", `Chọn SKU ${variant.sku}`);

                    const info = document.createElement("div");
                    info.className = "variant-option__product";
                    info.append(createText("strong", "", variant.sku));
                    info.append(createText("span", "", product.name));
                    info.append(createText("small", "", [variant.attributes, product.brand].filter(Boolean).join(" · ")));

                    const price = createText("div", "variant-option__price", currency.format(variant.originalPrice));
                    price.append(createText("small", "d-block", `Đang bán ${currency.format(variant.currentPrice)}`));

                    const selectVariant = () => {
                        selected.set(variant.id, {
                            id: variant.id,
                            sku: variant.sku,
                            name: product.name,
                            attributes: variant.attributes,
                            originalPrice: Number(variant.originalPrice),
                            currentPrice: Number(variant.currentPrice),
                            newPrice: Number(variant.currentPrice)
                        });
                        renderAll();
                    };

                    row.append(checkbox, info, price);
                    row.addEventListener("click", (event) => {
                        if (event.target === checkbox) return;
                        selectVariant();
                    });
                    checkbox.addEventListener("change", () => {
                        if (checkbox.checked) selectVariant();
                    });
                    sourceList.append(row);
                });
            });
        }

        function renderSelected() {
            selectedList.replaceChildren();
            const rows = [...selected.values()].sort((a, b) => a.sku.localeCompare(b.sku));
            selectedCount.textContent = String(rows.length);
            saveSummary.textContent = rows.length ? `${rows.length} biến thể sẽ được áp giá` : "Chưa chọn biến thể";

            if (!rows.length) {
                selectedList.append(createText("div", "empty-state compact", "Chọn biến thể từ danh sách bên trái."));
                return;
            }

            rows.forEach((variant) => {
                const row = document.createElement("article");
                row.className = "selected-variant";

                const info = document.createElement("div");
                info.append(createText("strong", "d-block", variant.sku));
                info.append(createText("span", "d-block", variant.name));
                info.append(createText("small", "", `${variant.attributes || "Không có thuộc tính"} · Giá niêm yết ${currency.format(variant.originalPrice)}`));

                const input = document.createElement("input");
                input.type = "number";
                input.min = "1";
                input.step = "0.01";
                input.className = "form-control";
                input.value = String(variant.newPrice);
                input.setAttribute("aria-label", `Giá chiến dịch cho ${variant.sku}`);
                input.addEventListener("input", () => {
                    variant.newPrice = Number(input.value);
                });

                const remove = document.createElement("button");
                remove.type = "button";
                remove.className = "btn btn-sm btn-outline-danger";
                remove.textContent = "Xóa";
                remove.addEventListener("click", () => {
                    selected.delete(variant.id);
                    renderAll();
                });

                row.append(info, input, remove);
                selectedList.append(row);
            });
        }

        function renderAll() {
            renderSource();
            renderSelected();
        }

        async function searchProducts() {
            searchAbortController?.abort();
            searchAbortController = new AbortController();
            sourceList.replaceChildren(createText("div", "empty-state compact", "Đang tải biến thể..."));

            const parameters = new URLSearchParams();
            const keyword = root.querySelector("[data-filter-keyword]").value.trim();
            const categoryId = root.querySelector("[data-filter-category]").value;
            const brandId = root.querySelector("[data-filter-brand]").value;
            if (keyword) parameters.set("keyword", keyword);
            if (categoryId) parameters.set("categoryId", categoryId);
            if (brandId) parameters.set("brandId", brandId);

            try {
                const result = await http.getJson(`/Admin/PriceCampaigns/GetProducts?${parameters}`, searchAbortController.signal);
                if (!result.success) throw new Error(result.message ?? "Không thể tải sản phẩm.");
                sourceProducts = result.data ?? [];
                renderSource();
            } catch (error) {
                if (error.name === "AbortError") return;
                sourceList.replaceChildren(createText("div", "empty-state compact", error.message));
            }
        }

        async function loadCampaign() {
            if (!campaignId) return;
            setFeedback(feedback, "Đang tải dữ liệu chiến dịch...");
            try {
                const result = await http.getJson(`/Admin/PriceCampaigns/GetCampaign/${campaignId}`);
                if (!result.success) throw new Error(result.message ?? "Không thể tải chiến dịch.");
                const data = result.data;
                root.querySelector("[data-campaign-name]").value = data.name ?? "";
                root.querySelector("[data-campaign-description]").value = data.description ?? "";
                root.querySelector("[data-campaign-start]").value = toLocalInput(data.startDateUtc);
                root.querySelector("[data-campaign-end]").value = toLocalInput(data.endDateUtc);
                rowVersionInput.value = data.rowVersion ?? "";
                (data.items ?? []).forEach((item) => selected.set(item.variantId, {
                    id: item.variantId,
                    sku: item.sku,
                    name: item.name,
                    attributes: item.attributes,
                    originalPrice: Number(item.originalPrice),
                    currentPrice: Number(item.currentPrice),
                    newPrice: Number(item.newPrice)
                }));
                setFeedback(feedback, "");
                renderAll();
            } catch (error) {
                setFeedback(feedback, error.message, "error");
            }
        }

        root.querySelector("[data-campaign-filter]").addEventListener("submit", (event) => {
            event.preventDefault();
            searchProducts();
        });

        root.querySelector("[data-clear-selected]").addEventListener("click", () => {
            selected.clear();
            renderAll();
        });

        root.querySelector("[data-apply-bulk]").addEventListener("click", () => {
            const type = root.querySelector("[data-bulk-type]").value;
            const value = Number(root.querySelector("[data-bulk-value]").value);
            if (!Number.isFinite(value) || value <= 0) {
                setFeedback(feedback, "Giá trị áp dụng hàng loạt phải lớn hơn 0.", "error");
                return;
            }

            selected.forEach((variant) => {
                const nextPrice = type === "percent"
                    ? variant.originalPrice * (1 - value / 100)
                    : type === "amount"
                        ? variant.originalPrice - value
                        : value;
                variant.newPrice = Math.max(0, Math.round(nextPrice));
            });
            setFeedback(feedback, "");
            renderSelected();
        });

        root.querySelector("[data-save-campaign]").addEventListener("click", async (event) => {
            const button = event.currentTarget;
            const name = root.querySelector("[data-campaign-name]").value.trim();
            const startValue = root.querySelector("[data-campaign-start]").value;
            const endValue = root.querySelector("[data-campaign-end]").value;
            const items = [...selected.values()].map((variant) => ({
                variantId: variant.id,
                newPrice: Number(variant.newPrice)
            }));

            if (!name || !startValue || !endValue || !items.length) {
                setFeedback(feedback, "Vui lòng nhập đủ thông tin và chọn ít nhất một biến thể.", "error");
                return;
            }
            if (items.some((item) => !Number.isFinite(item.newPrice) || item.newPrice <= 0)) {
                setFeedback(feedback, "Mọi giá chiến dịch phải lớn hơn 0.", "error");
                return;
            }

            button.disabled = true;
            setFeedback(feedback, "Đang lưu chiến dịch...");
            try {
                const result = await http.postJson("/Admin/PriceCampaigns/SaveCampaign", {
                    id: campaignId,
                    name,
                    description: root.querySelector("[data-campaign-description]").value.trim(),
                    startDate: new Date(startValue).toISOString(),
                    endDate: new Date(endValue).toISOString(),
                    rowVersion: rowVersionInput.value || null,
                    items
                });
                if (!result.success) throw new Error(result.message ?? "Không thể lưu chiến dịch.");
                rowVersionInput.value = result.rowVersion ?? rowVersionInput.value;
                setFeedback(feedback, result.message, "success");
                window.setTimeout(() => {
                    window.location.href = "/Admin/PriceCampaigns";
                }, 500);
            } catch (error) {
                setFeedback(feedback, error.message, "error");
                button.disabled = false;
            }
        });

        renderAll();
        Promise.all([searchProducts(), loadCampaign()]);
    }

    const indexRoot = document.querySelector("[data-price-campaign-index]");
    if (indexRoot) initializeIndex(indexRoot);

    const editorRoot = document.querySelector("[data-price-campaign-editor]");
    if (editorRoot) initializeEditor(editorRoot);
})();
