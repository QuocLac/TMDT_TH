using Microsoft.EntityFrameworkCore;

namespace WebApplication2.Models;

public sealed class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Brand> Brands => Set<Brand>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<ProductVariant> ProductVariants => Set<ProductVariant>();
    public DbSet<ProductImage> ProductImages => Set<ProductImage>();
    public DbSet<Promotion> Promotions => Set<Promotion>();
    public DbSet<ProductPromotion> ProductPromotions => Set<ProductPromotion>();
    public DbSet<PriceCampaign> PriceCampaigns => Set<PriceCampaign>();
    public DbSet<PriceCampaignItem> PriceCampaignItems => Set<PriceCampaignItem>();
    public DbSet<PriceHistory> PriceHistories => Set<PriceHistory>();
    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Address> Addresses => Set<Address>();
    public DbSet<PromotionCustomer> PromotionCustomers => Set<PromotionCustomer>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        ConfigureCatalog(modelBuilder);
        ConfigurePricing(modelBuilder);
        ConfigurePromotions(modelBuilder);
        ConfigureCustomers(modelBuilder);
    }

    private static void ConfigureCatalog(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasIndex(item => item.Slug).IsUnique();
            entity.Property(item => item.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            entity.HasOne(item => item.Parent)
                .WithMany(item => item.Children)
                .HasForeignKey(item => item.ParentId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Brand>(entity =>
        {
            entity.HasIndex(item => item.Slug).IsUnique();
            entity.Property(item => item.IsActive).HasDefaultValue(true);
            entity.Property(item => item.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasIndex(item => item.Slug).IsUnique();
            entity.HasIndex(item => new { item.CategoryId, item.BrandId, item.IsActive });
            entity.Property(item => item.IsActive).HasDefaultValue(true);
            entity.Property(item => item.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
        });

        modelBuilder.Entity<ProductVariant>(entity =>
        {
            entity.HasIndex(item => item.SKU).IsUnique();
            entity.HasIndex(item => new { item.ProductId, item.IsActive });
            entity.HasIndex(item => new { item.Color, item.Size });
            entity.Property(item => item.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            entity.Property(item => item.RowVersion).IsRowVersion();
            entity.ToTable(table =>
            {
                table.HasCheckConstraint("CK_ProductVariant_Price", "[Price] > 0");
                table.HasCheckConstraint("CK_ProductVariant_CurrentPrice", "[CurrentPrice] > 0");
                table.HasCheckConstraint("CK_ProductVariant_StockQuantity", "[StockQuantity] >= 0");
            });
        });

        modelBuilder.Entity<ProductImage>(entity =>
        {
            entity.HasIndex(item => new { item.ProductId, item.IsMain })
                .IsUnique()
                .HasFilter("[IsMain] = 1");
        });
    }

    private static void ConfigurePricing(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<PriceCampaign>(entity =>
        {
            entity.Property(item => item.IsActive).HasDefaultValue(true);
            entity.Property(item => item.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            entity.Property(item => item.RowVersion).IsRowVersion();
            entity.HasIndex(item => new { item.StartDate, item.EndDate, item.IsActive });
            entity.ToTable(table =>
                table.HasCheckConstraint("CK_PriceCampaign_Duration", "[EndDate] > [StartDate]"));
        });

        modelBuilder.Entity<PriceCampaignItem>(entity =>
        {
            entity.HasKey(item => new { item.CampaignId, item.VariantId });
            entity.HasIndex(item => item.VariantId);
            entity.HasOne(item => item.Campaign)
                .WithMany(item => item.CampaignItems)
                .HasForeignKey(item => item.CampaignId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(item => item.Variant)
                .WithMany(item => item.CampaignItems)
                .HasForeignKey(item => item.VariantId)
                .OnDelete(DeleteBehavior.Cascade);
            entity.ToTable(table =>
                table.HasCheckConstraint("CK_PriceCampaignItem_NewPrice", "[NewPrice] > 0"));
        });

        modelBuilder.Entity<PriceHistory>(entity =>
        {
            entity.HasIndex(item => new { item.ProductVariantId, item.CreatedAt });
            entity.HasOne(item => item.ProductVariant)
                .WithMany(item => item.PriceHistories)
                .HasForeignKey(item => item.ProductVariantId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }

    private static void ConfigurePromotions(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Promotion>(entity =>
        {
            entity.Property(item => item.IsActive).HasDefaultValue(true);
            entity.Property(item => item.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
            entity.HasIndex(item => new { item.StartDate, item.EndDate, item.IsActive });
            entity.ToTable(table =>
            {
                table.HasCheckConstraint("CK_Promotion_DiscountValue", "[DiscountValue] > 0");
                table.HasCheckConstraint("CK_Promotion_Duration", "[EndDate] > [StartDate]");
            });
        });

        modelBuilder.Entity<ProductPromotion>()
            .HasKey(item => new { item.ProductId, item.PromotionId });

        modelBuilder.Entity<PromotionCustomer>(entity =>
        {
            entity.HasKey(item => new { item.PromotionId, item.CustomerId });
            entity.HasOne(item => item.Promotion)
                .WithMany(item => item.PromotionCustomers)
                .HasForeignKey(item => item.PromotionId);
            entity.HasOne(item => item.Customer)
                .WithMany(item => item.PromotionCustomers)
                .HasForeignKey(item => item.CustomerId);
        });
    }

    private static void ConfigureCustomers(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Account>().HasIndex(item => item.Email).IsUnique();

        modelBuilder.Entity<Customer>()
            .HasOne(item => item.Account)
            .WithOne(item => item.Customer)
            .HasForeignKey<Customer>(item => item.AccountId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
